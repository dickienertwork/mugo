package to.dev.dev_android.events

class VideoPlayerPauseEvent {
    val action = "pause"
}