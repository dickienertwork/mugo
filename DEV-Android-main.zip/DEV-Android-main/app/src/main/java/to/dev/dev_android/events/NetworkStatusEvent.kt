package to.dev.dev_android.events

import to.dev.dev_android.util.network.NetworkStatus

class NetworkStatusEvent(val networkStatus: NetworkStatus)