package to.dev.dev_android.util.network

enum class NetworkStatus {
    OFFLINE,
    BACK_ONLINE
}
