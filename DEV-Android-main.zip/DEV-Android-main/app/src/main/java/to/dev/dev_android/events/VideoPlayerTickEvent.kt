package to.dev.dev_android.events

class VideoPlayerTickEvent(val seconds: String) {
    val action = "tick"
}