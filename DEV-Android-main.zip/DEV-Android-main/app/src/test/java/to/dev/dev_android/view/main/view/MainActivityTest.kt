package to.dev.dev_android.view.main.view

import org.junit.Test

import org.junit.Assert.*

class MainActivityTest {

    @Test
    fun `2 plus 2 equals 4`() {
        assertEquals(2+2, 4)
    }

    @Test
    fun onCreate() {


    }

    @Test
    fun onNewIntent() {
    }

    @Test
    fun onBackPressed() {
    }
}