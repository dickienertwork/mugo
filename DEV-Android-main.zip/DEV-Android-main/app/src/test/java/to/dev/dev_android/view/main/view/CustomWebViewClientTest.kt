package to.dev.dev_android.view.main.view

import org.junit.Test

import org.junit.Assert.*

class CustomWebViewClientTest {

    @Test
    fun onPageFinished() {
    }

    @Test
    fun shouldOverrideUrlLoading() {
    }

    @Test
    fun getContext() {
    }

    @Test
    fun getBinding() {
    }
}